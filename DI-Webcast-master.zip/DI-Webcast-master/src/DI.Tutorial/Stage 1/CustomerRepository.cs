﻿using System;
using System.Linq;

namespace DI.Tutorial.Stage1
{
    public class CustomerRepository
    {
        public void Save()
        {
            Console.WriteLine("Customer purchase saved.");
        }
    }
}
